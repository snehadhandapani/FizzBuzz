﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using System.Net.Http;
using System.Threading.Tasks;

namespace FizzBuzzTest
{
    namespace FizzBuzzTest
    {
        [TestFixture]
        public class FizzBuzzTest
        {
            private HttpClient _client;

            [SetUp]
            public void SetUp()
            {
                _client = new HttpClient();
                _client.BaseAddress = new Uri("https://localhost:7128/");
            }

            [TearDown]
            public void TearDown()
            {
                _client.Dispose();
            }

            [TestCase("1", "Divided 1 by 3 and Divided 1 by 5")]
            [TestCase("3", "Fizz")]
            [TestCase("5", "Buzz")]
            [TestCase("15", "FizzBuzz")]
            public async Task Index_ReturnsCorrectResult(string input, string expectedResult)
            {
                // Arrange
                var content = new StringContent($"inputValues={input}", Encoding.UTF8, "application/x-www-form-urlencoded");
                //var response = await _client.PostAsync("https://localhost:7128/FizzBuzz/Index", content);
                var response = await _client.PostAsync("/FizzBuzz/Index", content);


                // Log information for troubleshooting
               // Console.WriteLine($"Request URI: {response.RequestMessage.RequestUri}");
             //   Console.WriteLine($"Response Status Code: {response.StatusCode}");

                response.EnsureSuccessStatusCode();
                var responseContent = await response.Content.ReadAsStringAsync();

                // Assert
                Assert.IsNotNull(responseContent, "Content should not be null");
                Assert.IsTrue(responseContent.Contains(expectedResult), $"Expected result '{expectedResult}' not found in the content: {responseContent}");
            }
        }
    }


}
