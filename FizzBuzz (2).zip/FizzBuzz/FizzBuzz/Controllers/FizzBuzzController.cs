﻿using FizzBuzz.IServices;
using Microsoft.AspNetCore.Mvc;
using FizzBuzz.Models;
using FizzBuzz.Services;

namespace FizzBuzz.Controllers
{
    public class FizzBuzzController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // Controllers/FizzBuzzController.cs
        [HttpPost]
        public IActionResult Index( string inputValues)
        {
            ViewBag.InputValues = inputValues;
            List<FizzBuzzModel> results = new List<FizzBuzzModel>();

                // Split the input values into an array
                var values = inputValues.Split(',');

                foreach (var value in values)
                {
                    var result = SingletonFizzBuzzService.Instance.ProcessInput(value.Trim());
                    results.Add(result);
                }
            
            return View(results);
        }
    }
}
