﻿using FizzBuzz.Models;

namespace FizzBuzz.IServices
{
    public interface IFizzBuzzService
    {
        FizzBuzzModel ProcessInput(string input);
    }
}
