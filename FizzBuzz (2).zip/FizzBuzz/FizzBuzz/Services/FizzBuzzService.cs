﻿using FizzBuzz.IServices;
using FizzBuzz.Models;

namespace FizzBuzz.Services
{
    public class FizzBuzzService : IFizzBuzzService
    {
        public FizzBuzzModel ProcessInput(string input)
        {
            FizzBuzzModel result = new FizzBuzzModel();
            result.Input = input;
            if (int.TryParse(input, out int number)) 
            {

                if (number % 3 == 0 && number % 5 == 0)
                {
                    result.Output = FizzBuzzConstants.FizzBuzz;
                }
                else if (number % 3 == 0)
                {
                    result.Output = FizzBuzzConstants.Fizz;
                }
                else if (number % 5 == 0)
                {
                    result.Output = FizzBuzzConstants.Buzz;
                }
                else
                {
                    result.Output = $"Divided {number} by 3 and Divided {number} by 5";
                }
            }
            else
            {
                result.Output = FizzBuzzConstants.InvalidItem;
            }
            return result;


        }
    }
}
