using FizzBuzz.IServices;
using FizzBuzz.Models;
using FizzBuzz.Services;
using Xunit;

public class FizzBuzzTest
{
    private readonly IFizzBuzzService _fizzBuzzService;

    public FizzBuzzTest()
    {
        _fizzBuzzService = new FizzBuzzService();
    }

    [Theory]
     [InlineData(1, FizzBuzzConstants.DividedByThreeAndFive)]
    [InlineData(3, FizzBuzzConstants.Fizz)]
    [InlineData(5, FizzBuzzConstants.Buzz)]
    [InlineData(15, FizzBuzzConstants.FizzBuzz)]
    [InlineData(7, FizzBuzzConstants.DividedByThreeAndFive)]
    [InlineData(10, FizzBuzzConstants.Buzz)]
    [InlineData(30, FizzBuzzConstants.FizzBuzz)]
    [InlineData(8, FizzBuzzConstants.DividedByThreeAndFive)]
    [InlineData(11, FizzBuzzConstants.DividedByThreeAndFive)] // Updated expected result for input 11

    public void ProcessInput_ReturnsExpectedResult(int input, string expectedResult)
    {
        // Arrange
        var fizzBuzzModel = new FizzBuzzModel { Input = input.ToString() };

        // Act
        var result = _fizzBuzzService.ProcessInput(fizzBuzzModel.Input);

        // Assert
        // Assert.Equal(expectedResult, result.Output);
        Assert.Equal(string.Format(expectedResult, input), result.Output);
    }


    [Theory]
    [InlineData("123", FizzBuzzConstants.Fizz)]
    [InlineData("Sneha", FizzBuzzConstants.InvalidItem)]
    [InlineData("", FizzBuzzConstants.InvalidItem)] // Test case for empty input
    [InlineData(null, FizzBuzzConstants.InvalidItem)] // Test case for null input
    public void ProcessInput_ReturnsExpectedResultForString(string input, string expectedResult)
    {
        // Arrange
        var fizzBuzzModel = new FizzBuzzModel { Input = input };

        // Act
        var result = _fizzBuzzService.ProcessInput(fizzBuzzModel.Input);

        // Assert
        Assert.Equal(expectedResult, result.Output);
    }

}
