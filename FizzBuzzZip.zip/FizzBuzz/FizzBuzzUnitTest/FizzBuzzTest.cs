using FizzBuzz.IServices;
using FizzBuzz.Models;
using FizzBuzz.Services;
using Xunit;

public class FizzBuzzTest
{
    private readonly IFizzBuzzService _fizzBuzzService;

    public FizzBuzzTest()
    {
        _fizzBuzzService = new FizzBuzzService();
    }

    [Theory]
    [InlineData(1, "Divided 1 by 3 and Divided 1 by 5")]
    [InlineData(3, "Fizz")]
    [InlineData(5, "Buzz")]
    [InlineData(15, "FizzBuzz")]
    [InlineData(7, "Divided 7 by 3 and Divided 7 by 5")]
    [InlineData(10, "Buzz")]
    [InlineData(30, "FizzBuzz")]
    [InlineData(8, "Divided 8 by 3 and Divided 8 by 5")]
    [InlineData(11, "Divided 11 by 3 and Divided 11 by 5")] // Updated expected result for input 11

    public void ProcessInput_ReturnsExpectedResult(int input, string expectedResult)
    {
        // Arrange
        var fizzBuzzModel = new FizzBuzzModel { Input = input.ToString() };

        // Act
        var result = _fizzBuzzService.ProcessInput(fizzBuzzModel.Input);

        // Assert
        Assert.Equal(expectedResult, result.Output);
    }


    [Theory]
    [InlineData("123", "Fizz")]
    [InlineData("Sneha", "Invalid Item")]
    [InlineData("", "Invalid Item")] // Test case for empty input
    [InlineData(null, "Invalid Item")] // Test case for null input
    public void ProcessInput_ReturnsExpectedResultForString(string input, string expectedResult)
    {
        // Arrange
        var fizzBuzzModel = new FizzBuzzModel { Input = input };

        // Act
        var result = _fizzBuzzService.ProcessInput(fizzBuzzModel.Input);

        // Assert
        Assert.Equal(expectedResult, result.Output);
    }

}
