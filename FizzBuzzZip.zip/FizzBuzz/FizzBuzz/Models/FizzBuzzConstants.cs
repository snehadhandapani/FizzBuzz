﻿namespace FizzBuzz.Models
{
    public class FizzBuzzConstants
    {
        public const string Fizz = "Fizz";
        public const string Buzz = "Buzz";
        public const string FizzBuzz = "FizzBuzz";
        public const string InvalidItem = "Invalid Item";
    }
}
