﻿using FizzBuzz.IServices;

namespace FizzBuzz.Services
{
    public class OutputService :IOutputService
    {
        public void DisplayOutput(string output)
        {
            Console.WriteLine($"Result is {output}");
        }
    }
}
