﻿namespace FizzBuzz.Services
{
    public class SingletonFizzBuzzService
    {
        private static readonly Lazy<FizzBuzzService> _instance = new Lazy<FizzBuzzService>(() => new FizzBuzzService( new OutputService()));

        public static FizzBuzzService Instance => _instance.Value;
    }
}
