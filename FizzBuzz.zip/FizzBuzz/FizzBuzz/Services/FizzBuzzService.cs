﻿using FizzBuzz.IServices;
using FizzBuzz.Models;

namespace FizzBuzz.Services
{
    public class FizzBuzzService : IFizzBuzzService
    {
     

        private readonly IOutputService _outputService;

        public FizzBuzzService(  IOutputService outputService)
        {
            _outputService = outputService;
        }

        public FizzBuzzModel ProcessInput(string input)
        {
            FizzBuzzModel result = new FizzBuzzModel();

            if (int.TryParse(input, out int number)) 
            {

                if (number % 3 == 0 && number % 5 == 0)
                {
                    result.Output = "FizzBuzz";
                }
                else if (number % 3 == 0)
                {
                    result.Output = "Fizz";
                }
                else if (number % 5 == 0)
                {
                    result.Output = "Buzz";
                }
                else
                {
                    result.Output = $"Divided {number} by 3 and Divided {number} by 5";
                }
            }
            else
            {
                result.Output = "Invalid item";
            }

            _outputService.DisplayOutput(result.Output);

            return result;


        }
    }
}
