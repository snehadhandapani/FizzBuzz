﻿using FizzBuzz.IServices;
using Microsoft.AspNetCore.Mvc;
using FizzBuzz.Models;
using FizzBuzz.Services;

namespace FizzBuzz.Controllers
{
    public class FizzBuzzController : Controller
    {
        private readonly IFizzBuzzService _fizzBuzzService;

        public FizzBuzzController(IFizzBuzzService fizzBuzzService)
        {
            _fizzBuzzService = fizzBuzzService;
        }

        public IActionResult Index()
        {
            return View();
        }

        // Controllers/FizzBuzzController.cs
        [HttpPost]
        public IActionResult Index(string inputType, string inputValues)
        {
            List<FizzBuzzModel> results = new List<FizzBuzzModel>();

            if (inputType == "single")
            {
                // Process a single value
                var result = SingletonFizzBuzzService.Instance.ProcessInput(inputValues);
                results.Add(result);
            }
            else if (inputType == "multiple")
            {
                // Split the input values into an array
                var values = inputValues.Split(',');

                foreach (var value in values)
                {
                    var result = SingletonFizzBuzzService.Instance.ProcessInput(value.Trim());
                    results.Add(result);
                }
            }

            return View(results);
        }
    }
}
