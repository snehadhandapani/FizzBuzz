﻿namespace FizzBuzz.Models
{
    public class FizzBuzzModel
    {
        public string Input { get; set; }
        public string Output { get; set; }
    }
}
