﻿namespace FizzBuzz.IServices
{
    public interface IOutputService
    {
        void DisplayOutput(string output);
    }
}
